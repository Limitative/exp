from typing import List, Tuple, Optional
import os

# 定义类型别名以便理解
Vertex = Tuple[float, float, float]
# 面的定义：(顶点索引列表, RGB颜色元组)
Face = Tuple[List[int], Tuple[int, int, int]]

class ModelData:
    """
    一个统一的数据结构，用于存储和操作三维模型数据。
    """

    def __init__(self, vertices: List[Vertex] = None, faces: List[Face] = None):
        self.vertices = vertices if vertices else []
        self.faces = faces if faces else []

    def __repr__(self):
        return f"ModelData(vertices={len(self.vertices)}, faces={len(self.faces)})"

def read_off(filepath: str) -> Optional[ModelData]:
    """
    从 OFF 文件中读取模型数据。
    支持处理空文件或格式不正确的文件。
    """
    if not os.path.exists(filepath) or os.path.getsize(filepath) == 0:
        print(f"警告: 文件 '{filepath}' 为空或不存在。")
        return ModelData()

    try:
        with open(filepath, 'r') as f:
            lines = f.readlines()
            lines = [line.strip() for line in lines if line.strip()]

            if not lines or lines[0] != 'OFF':
                raise ValueError("文件不是有效的 OFF 格式 (缺少 'OFF' 标识符)。")

            # 解析顶点、面和边的数量
            parts = lines[1].split()
            num_vertices = int(parts[0])
            num_faces = int(parts[1])
            # num_edges = int(parts[2]) # 边信息在此次作业中不使用

            # 解析顶点
            vertex_lines = lines[2: 2 + num_vertices]
            vertices = [tuple(map(float, line.split()[:3])) for line in vertex_lines]

            # 解析面和颜色
            face_lines = lines[2 + num_vertices: 2 + num_vertices + num_faces]
            faces = []
            for line in face_lines:
                parts = list(map(int, line.split()))
                num_face_vertices = parts[0]
                face_indices = parts[1: 1 + num_face_vertices]

                # 检查是否有颜色信息
                if len(parts) > 1 + num_face_vertices:
                    color = tuple(parts[1 + num_face_vertices: 4 + num_face_vertices])
                else:
                    color = (200, 200, 200)  # 如果没有颜色，提供默认灰色
                faces.append((face_indices, color))

            return ModelData(vertices, faces)

    except (IOError, IndexError, ValueError) as e:
        print(f"错误: 读取文件 '{filepath}' 失败: {e}")
        return None

def write_off(filepath: str, model: ModelData):
    """
    将 ModelData 对象写入到 OFF 文件。
    """
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w') as f:
            # 写入文件头
            f.write("OFF\n")
            num_vertices = len(model.vertices)
            num_faces = len(model.faces)
            f.write(f"{num_vertices} {num_faces} 0\n\n")

            # 写入顶点坐标
            for v in model.vertices:
                f.write(f"{v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")

            f.write("\n")

            # 写入面定义和颜色
            for face_indices, color in model.faces:
                num_face_vertices = len(face_indices)
                indices_str = " ".join(map(str, face_indices))
                color_str = f"{color[0]} {color[1]} {color[2]}"
                f.write(f"{num_face_vertices} {indices_str} {color_str}\n")

        print(f"成功: 模型已保存到 '{filepath}'")

    except IOError as e:
        print(f"错误: 写入文件 '{filepath}' 失败: {e}")