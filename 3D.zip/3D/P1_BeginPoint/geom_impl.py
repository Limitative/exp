import math
import random
# 注意：这里直接从 off_io 导入 AssetData
from off_io import AssetData


# ================= 辅助函数 =================

def get_circle_points(n, radius, z):
    """生成圆周上的点"""
    points = []
    for i in range(n):
        angle = 2 * math.pi * i / n
        points.append([radius * math.cos(angle), radius * math.sin(angle), z])
    return points


def create_prism_data(n, radius, height, is_star=False, inner_r=None):
    """通用棱柱生成逻辑"""
    vertices = []
    faces = []
    colors = []

    h_half = height / 2.0

    # 1. 生成顶点
    if is_star:
        # 星形：每层 2*n 个点
        for z in [-h_half, h_half]:
            for i in range(n):
                angle = 2 * math.pi * i / n
                # 外点
                vertices.append([radius * math.cos(angle), radius * math.sin(angle), z])
                # 内点
                angle_next = angle + math.pi / n
                vertices.append([inner_r * math.cos(angle_next), inner_r * math.sin(angle_next), z])
        points_per_layer = 2 * n
    else:
        # 普通多边形：每层 n 个点
        vertices.extend(get_circle_points(n, radius, -h_half))  # 底
        vertices.extend(get_circle_points(n, radius, h_half))  # 顶
        points_per_layer = n

    # 2. 生成侧面
    # 侧面颜色随机
    base_idx = 0
    top_idx = points_per_layer

    for i in range(points_per_layer):
        curr = i
        next_p = (i + 1) % points_per_layer

        # 构成四边形面: [下当前, 下下一个, 上下一个, 上当前]
        # 注意顶点顺序逆时针
        face = [base_idx + curr, base_idx + next_p, top_idx + next_p, top_idx + curr]
        faces.append(face)
        colors.append([random.randint(50, 255), random.randint(50, 255), 200])

    # 3. 生成底面 (反序，法线向下)
    faces.append(list(range(points_per_layer - 1, -1, -1)))
    colors.append([100, 100, 100])

    # 4. 生成顶面
    faces.append(list(range(points_per_layer, points_per_layer * 2)))
    colors.append([200, 200, 200])

    return vertices, faces, colors


# ================= 实现函数 =================

def cube_impl(args) -> AssetData:
    s = getattr(args, 'size', 1.0) / 2.0
    vertices = [
        [s, s, s], [-s, s, s], [-s, -s, s], [s, -s, s],
        [s, s, -s], [-s, s, -s], [-s, -s, -s], [s, -s, -s]
    ]
    # 注意面索引顺序
    faces = [
        [0, 1, 2, 3], [4, 7, 6, 5], [0, 4, 5, 1],
        [1, 5, 6, 2], [2, 6, 7, 3], [4, 0, 3, 7]
    ]
    colors = [[255, 0, 0] for _ in faces]
    return AssetData(args.dst, vertices, faces, colors)


def pyramid_impl(args) -> AssetData:
    # 四棱锥
    r = getattr(args, 'radius', 1.0)
    h = getattr(args, 'height', 1.5)

    vertices = [
        [r, r, 0], [-r, r, 0], [-r, -r, 0], [r, -r, 0],  # 底面0-3
        [0, 0, h]  # 顶点4
    ]
    faces = [
        [3, 2, 1, 0],  # 底面
        [0, 1, 4], [1, 2, 4], [2, 3, 4], [3, 0, 4]  # 侧面
    ]
    colors = [[100, 100, 100]] + [[255, 100, 100]] * 4
    return AssetData(args.dst, vertices, faces, colors)


def poly17_impl(args) -> AssetData:
    # 正17边形 (稍微给点厚度做成薄片，不然单面有些软件看不清)
    r = getattr(args, 'radius', 1.0)
    v, f, c = create_prism_data(17, r, 0.1)
    return AssetData(args.dst, v, f, c)


def prism5_impl(args) -> AssetData:
    # 五棱柱
    r = getattr(args, 'radius', 1.0)
    h = getattr(args, 'height', 2.0)
    v, f, c = create_prism_data(5, r, h)
    return AssetData(args.dst, v, f, c)


def cylinder_impl(args) -> AssetData:
    # 圆柱 (32棱柱)
    r = getattr(args, 'radius', 1.0)
    h = getattr(args, 'height', 2.0)
    v, f, c = create_prism_data(32, r, h)
    return AssetData(args.dst, v, f, c)


def prism_star_impl(args) -> AssetData:
    # 星柱
    r = getattr(args, 'radius', 1.0)
    h = getattr(args, 'height', 2.0)
    v, f, c = create_prism_data(5, r, h, is_star=True, inner_r=r * 0.4)
    return AssetData(args.dst, v, f, c)


def custom1_impl(args) -> AssetData:
    # 自定义：球体 (简单的经纬度球)
    r = getattr(args, 'radius', 1.0)
    lat = 10;
    lon = 20
    vertices = []
    faces = []
    colors = []

    # 顶点
    for i in range(lat + 1):
        theta = i * math.pi / lat
        y = r * math.cos(theta)
        ring_r = r * math.sin(theta)
        for j in range(lon):
            phi = j * 2 * math.pi / lon
            x = ring_r * math.cos(phi)
            z = ring_r * math.sin(phi)
            vertices.append([x, y, z])

    # 面
    for i in range(lat):
        for j in range(lon):
            p1 = i * lon + j
            p2 = p1 + lon
            p3 = p1 + lon + 1
            p4 = p1 + 1

            # 处理经度闭环
            if (j == lon - 1):
                p3 -= lon
                p4 -= lon

            faces.append([p1, p2, p3, p4])
            colors.append([int(255 * i / lat), 100, 200])

    return AssetData(args.dst, vertices, faces, colors)


def custom2_impl(args) -> AssetData:
    # 自定义2：金字塔阵列
    return pyramid_impl(args)