from argparse import ArgumentParser
import os
import sys

# 导入当前目录下的模块
from off_io import write_off_file, AssetData
from geom_impl import (
    cube_impl,
    pyramid_impl,
    poly17_impl,
    prism5_impl,
    cylinder_impl,
    prism_star_impl,
    custom1_impl,
    custom2_impl,
)

# 映射字典
DrawImpl = {
    'cube': cube_impl,
    'pyramid': pyramid_impl,
    'poly17': poly17_impl,
    'prism5': prism5_impl,
    'cylinder': cylinder_impl,
    'prism_star': prism_star_impl,
    'custom1': custom1_impl,
    'custom2': custom2_impl,
}


def draw(args):
    # 安全检查
    if args.geom not in DrawImpl:
        print(f"错误：不支持的几何体 '{args.geom}'")
        return

    # 调用对应的函数
    print(f"正在生成: {args.geom} ...")
    draw_data: AssetData = DrawImpl[args.geom](args)

    # 确保目标文件夹存在
    output_dir = os.path.dirname(args.dst)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 写入文件
    write_off_file(args.dst, draw_data)


if __name__ == "__main__":
    parser = ArgumentParser()

    # 必选参数
    parser.add_argument('--geom', type=str, required=True, choices=DrawImpl.keys(), help='几何体类型')
    parser.add_argument('--dst', type=str, required=True, help='输出文件路径 (例如 output/test.off)')

    # 可选参数
    parser.add_argument('--radius', type=float, default=1.0, help='半径')
    parser.add_argument('--height', type=float, default=2.0, help='高度')
    parser.add_argument('--size', type=float, default=1.0, help='尺寸')

    args = parser.parse_args()

    draw(args)