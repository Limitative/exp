from argparse import ArgumentParser
from typing import Union


class AssetData:
    def __init__(self, path: str, vertices: list, faces: list, colors: list):
        """
        :param path: 文件路径
        :param vertices: 顶点列表 [[x,y,z], ...]
        :param faces: 面索引列表 [[v1,v2,v3,...], ...]
        :param colors: 颜色列表 [[r,g,b], ...] (对应每个面的颜色)
        """
        self.path = path
        self.vertices = vertices
        self.faces = faces
        self.colors = colors

    def __str__(self):
        return f"{self.path}: {len(self.vertices)} vertices, {len(self.faces)} faces"


def read_off_file(off_file: str) -> AssetData:
    # 暂时不需要读取功能，如果需要可后续补充
    return AssetData(off_file, [], [], [])


def write_off_file(off_file: str, off_data: Union[AssetData, None]):
    if off_data is None:
        print("错误：没有数据可写入")
        return

    try:
        with open(off_file, "w") as f:
            # 1. 写入头
            f.write("OFF\n")

            # 2. 写入数量: 顶点数 面数 边数(0)
            f.write(f"{len(off_data.vertices)} {len(off_data.faces)} 0\n\n")

            # 3. 写入顶点
            for v in off_data.vertices:
                # 确保是浮点数格式
                f.write(f"{float(v[0]):.6f} {float(v[1]):.6f} {float(v[2]):.6f}\n")

            # 4. 写入面 + 颜色
            # 格式: N v1 v2 ... vN R G B
            for i, face in enumerate(off_data.faces):
                # 面顶点个数
                n_verts = len(face)
                # 顶点索引字符串
                face_str = " ".join(map(str, face))

                # 颜色处理
                color_str = ""
                if off_data.colors and i < len(off_data.colors):
                    r, g, b = off_data.colors[i]
                    # OFF文件颜色通常是 0-255 整数或 0-1 浮点数，MeshLab 兼容 0-255 整数
                    color_str = f" {int(r)} {int(g)} {int(b)}"

                f.write(f"{n_verts} {face_str}{color_str}\n")

        print(f"成功生成文件: {off_file}")

    except Exception as e:
        print(f"写入文件失败: {e}")


if __name__ == '__main__':
    # 简单的测试代码
    pass