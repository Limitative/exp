from argparse import ArgumentParser
from typing import Union

class AssetData:
    def __init__(self, path: str, vertices: list, faces: list, colors: list):
        self.path = path
        self.vertices = vertices
        self.faces = faces
        self.colors = colors

    def __str__(self):
        return f"{self.path}: {len(self.vertices)} vertices, {len(self.faces)} faces"


def read_off_file(off_file: str) -> AssetData:
    vertices = []
    faces = []
    colors = []
    with open(off_file, 'r') as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]

        if not lines or lines[0] != 'OFF':
            raise ValueError("文件格式错误：缺少 'OFF' 标识符。")

            # 解析顶点、面和边的数量
        counts = list(map(int, lines[1].split()))
        num_vertices, num_faces = counts[0], counts[1]

        # 解析顶点坐标
        vertex_lines = lines[2: 2 + num_vertices]
        for line in vertex_lines:
            vertices.append(list(map(float, line.split()[:3])))

        # 解析面和颜色数据
        face_lines = lines[2 + num_vertices: 2 + num_vertices + num_faces]
        for line in face_lines:
            parts = [int(p) for p in line.split()]
            num_face_vertices = parts[0]

            # 提取面的顶点索引
            face_indices = parts[1: 1 + num_face_vertices]
            faces.append(face_indices)

            # 检查并提取颜色信息
            if len(parts) > 1 + num_face_vertices:
                colors.append(parts[1 + num_face_vertices: 4 + num_face_vertices])
            else:
                # 如果没有颜色信息，提供一个默认的灰色
                colors.append([200, 200, 200])

    return AssetData(off_file, vertices, faces, colors)

def write_off_file(off_file: str, off_data: Union[AssetData, None]):
    if not off_data:
        print("错误：没有可写入的数据。")
        return

    with open(off_file, "w") as f:
        # 写入文件头
        f.write("OFF\n")
        num_vertices = len(off_data.vertices)
        num_faces = len(off_data.faces)
        f.write(f"{num_vertices} {num_faces} 0\n\n")

        # 写入所有顶点坐标
        for v in off_data.vertices:
            f.write(f"{v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")

        f.write("\n")

        # 写入所有面定义和颜色
        for i, face_indices in enumerate(off_data.faces):
            num_face_vertices = len(face_indices)
            indices_str = " ".join(map(str, face_indices))

            # 附加颜色信息
            color_str = ""
            if off_data.colors and i < len(off_data.colors):
                color_str = " " + " ".join(map(str, off_data.colors[i]))

            f.write(f"{num_face_vertices} {indices_str}{color_str}\n")


if __name__ == '__main__':
    parser = ArgumentParser(description="从一个源 OFF 文件读取数据，并将其写入一个新的目标 OFF 文件。")

    # 添加命令行参数
    parser.add_argument('--src', type=str, required=True, help='源 .off 文件路径')
    parser.add_argument('--dst', type=str, required=True, help='目标 .off 文件路径')

    args = parser.parse_args()

    # 从源文件读取数据
    print(f"正在从 '{args.src}' 读取...")
    test_data: AssetData = read_off_file(args.src)
    print(test_data)

    # 将读取的数据写入目标文件
    print(f"正在写入到 '{args.dst}'...")
    write_off_file(args.dst, test_data)
    print("操作完成。")
