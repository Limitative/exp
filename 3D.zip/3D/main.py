import argparse
import random
import sys
from typing import Tuple

from off_handler import write_off
from geometry_generator import (
    generate_cube,
    generate_pyramid,
    generate_prism,
    generate_interlocking_cubes  # 导入新的模型生成器
)


def parse_color(color_str: str) -> Tuple[int, int, int]:
    """将 'R,G,B' 格式的字符串解析为颜色元组。"""
    try:
        r, g, b = map(int, color_str.split(','))
        if not (0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255):
            raise ValueError
        return (r, g, b)
    except (ValueError, TypeError):
        raise argparse.ArgumentTypeError(
            f"颜色格式无效: '{color_str}'. 请使用 'R,G,B' 格式, 例如 '255,128,0'."
        )


def main():
    parser = argparse.ArgumentParser(
        description="一个计算并生成多种几何体 OFF 文件的程序。",
        formatter_class=argparse.RawTextHelpFormatter
    )

    # --- 更新支持的形状列表 ---
    supported_shapes = [
        'triangular_pyramid', 'square_pyramid', 'heptadecagon_prism',
        'cube', 'pentagonal_prism', 'cylinder', 'star_prism',
        'interlocking_cubes',  # 添加新模型
        'all'
    ]
    parser.add_argument(
        'shape',
        type=str,
        choices=supported_shapes,
        help="要生成的几何体类型。\n"
             "可选值: \n"
             "  triangular_pyramid - 三棱锥\n"
             "  square_pyramid     - 四棱锥/金字塔\n"
             "  heptadecagon_prism - 正十七边形棱柱\n"
             "  cube               - 立方体\n"
             "  pentagonal_prism   - 五棱柱\n"
             "  cylinder           - 圆柱 (用64边棱柱模拟)\n"
             "  star_prism         - 五角星形柱\n"
             "  interlocking_cubes - 自定义交叉立方体模型\n"  # 更新帮助文本
             "  all                - 生成所有支持的模型"
    )

    parser.add_argument(
        '--size', '-s', type=float, default=None,
        help="几何体的基础尺寸。\n默认为 1.0 到 3.0 之间的随机值。"
    )
    parser.add_argument(
        '--height', '-ht', type=float, default=None,
        help="棱柱、棱锥或圆柱的高度。\n默认为 --size 参数的值或随机值。"
    )
    parser.add_argument(
        '--color', '-c', type=parse_color, default=None,
        help="为整个模型指定一个RGB颜色，格式 'R,G,B'。\n若不指定，则每个面颜色随机。"
    )
    parser.add_argument(
        '--random_colors', action='store_true',
        help="强制为模型的每个面指定随机颜色，此选项会覆盖 --color 参数。"
    )
    parser.add_argument(
        '--output', '-o', type=str, default='./output',
        help="保存生成 .off 文件的目录。\n默认为 './output'。"
    )

    args = parser.parse_args()

    def generate_single_shape(shape_name):
        size = args.size if args.size is not None else random.uniform(1.0, 2.0)
        height = args.height if args.height is not None else size
        use_random_face_colors = args.random_colors or (args.color is None)
        base_color = args.color if args.color is not None else (
        random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))

        model = None

        print(f"\n正在生成 '{shape_name}'...")
        print(f"  - 尺寸: {size:.2f}, 高度: {height:.2f}")
        if use_random_face_colors:
            print("  - 颜色: 每个面使用随机颜色")
        else:
            print(f"  - 主颜色: {base_color}")

        # --- 更新模型生成调用逻辑 ---
        if shape_name == 'cube':
            model = generate_cube(size, base_color, use_random_face_colors)
        elif shape_name == 'triangular_pyramid':
            model = generate_pyramid(3, size, height, base_color, use_random_face_colors)
        elif shape_name == 'square_pyramid':
            model = generate_pyramid(4, size, height, base_color, use_random_face_colors)
        elif shape_name == 'pentagonal_prism':
            model = generate_prism(5, size, height, base_color, use_random_face_colors)
        elif shape_name == 'heptadecagon_prism':
            model = generate_prism(17, size, height, base_color, use_random_face_colors)
        elif shape_name == 'cylinder':
            model = generate_prism(64, size, height, base_color, use_random_face_colors)
        elif shape_name == 'star_prism':
            model = generate_prism(5, size, height, base_color, use_random_face_colors, is_star=True)
        elif shape_name == 'interlocking_cubes':  # 替换 'gear'
            model = generate_interlocking_cubes(size, base_color, use_random_face_colors)

        if model:
            output_path = f"{args.output}/{shape_name}.off"
            write_off(output_path, model)
        else:
            print(f"错误: 未知的几何体类型 '{shape_name}'", file=sys.stderr)

    if args.shape == 'all':
        all_shapes = [s for s in supported_shapes if s != 'all']
        for shape_name in all_shapes:
            generate_single_shape(shape_name)
    else:
        generate_single_shape(args.shape)


if __name__ == '__main__':
    main()