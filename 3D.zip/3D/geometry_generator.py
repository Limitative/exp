import math
import random
from off_handler import ModelData, Vertex, Face
from typing import List, Tuple


def get_random_color() -> Tuple[int, int, int]:
    """生成一个随机的 RGB 颜色。"""
    return (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))


def generate_prism(
        n: int,
        radius: float,
        height: float,
        color: Tuple[int, int, int],
        random_face_colors: bool,
        is_star: bool = False,
        inner_radius_ratio: float = 0.5
) -> ModelData:
    """
    通用的棱柱生成器。
    """
    vertices: List[Vertex] = []
    faces: List[Face] = []

    angle_step = 2 * math.pi / n

    if is_star:
        for i in range(n):
            outer_angle = i * angle_step
            inner_angle = outer_angle + angle_step / 2
            vertices.append((radius * math.cos(outer_angle), -height / 2, radius * math.sin(outer_angle)))
            vertices.append((radius * inner_radius_ratio * math.cos(inner_angle), -height / 2,
                             radius * inner_radius_ratio * math.sin(inner_angle)))
            vertices.append((radius * math.cos(outer_angle), height / 2, radius * math.sin(outer_angle)))
            vertices.append((radius * inner_radius_ratio * math.cos(inner_angle), height / 2,
                             radius * inner_radius_ratio * math.sin(inner_angle)))
    else:
        for i in range(n):
            angle = i * angle_step
            x = radius * math.cos(angle)
            z = radius * math.sin(angle)
            vertices.append((x, -height / 2, z))
            vertices.append((x, height / 2, z))

    if is_star:
        for i in range(n):
            p0_b_outer, p1_b_inner = i * 4, i * 4 + 1
            p0_t_outer, p1_t_inner = i * 4 + 2, i * 4 + 3
            p2_b_outer, p2_t_outer = ((i + 1) % n) * 4, ((i + 1) % n) * 4 + 2
            faces.append(
                ([p0_b_outer, p2_b_outer, p2_t_outer, p0_t_outer], get_random_color() if random_face_colors else color))
            faces.append(
                ([p1_b_inner, p0_b_outer, p0_t_outer, p1_t_inner], get_random_color() if random_face_colors else color))

        bottom_center_face = [i * 4 + 1 for i in range(n)]
        top_center_face = [i * 4 + 3 for i in range(n)]
        faces.append((bottom_center_face, get_random_color() if random_face_colors else color))
        faces.append((top_center_face[::-1], get_random_color() if random_face_colors else color))

        for i in range(n):
            p_outer, p_inner_curr = i * 4, i * 4 + 1
            p_inner_prev = ((i - 1 + n) % n) * 4 + 1
            faces.append(([p_outer, p_inner_prev, p_inner_curr], get_random_color() if random_face_colors else color))
            p_outer_top, p_inner_curr_top = i * 4 + 2, i * 4 + 3
            p_inner_prev_top = ((i - 1 + n) % n) * 4 + 3
            faces.append(([p_outer_top, p_inner_curr_top, p_inner_prev_top],
                          get_random_color() if random_face_colors else color))
    else:
        for i in range(n):
            b1, t1 = i * 2, i * 2 + 1
            b2, t2 = ((i + 1) % n) * 2, ((i + 1) % n) * 2 + 1
            faces.append(([b1, b2, t2, t1], get_random_color() if random_face_colors else color))
        bottom_face = [i * 2 for i in range(n)]
        top_face = [i * 2 + 1 for i in range(n)]
        faces.append((bottom_face, get_random_color() if random_face_colors else color))
        faces.append((top_face[::-1], get_random_color() if random_face_colors else color))

    return ModelData(vertices, faces)


def generate_pyramid(
        n: int, radius: float, height: float, color: Tuple, random_face_colors: bool
) -> ModelData:
    """通用棱锥生成器。"""
    vertices: List[Vertex] = []
    faces: List[Face] = []
    angle_step = 2 * math.pi / n
    for i in range(n):
        angle = i * angle_step
        vertices.append((radius * math.cos(angle), 0, radius * math.sin(angle)))
    vertices.append((0, height, 0))
    for i in range(n):
        faces.append(([i, (i + 1) % n, n], get_random_color() if random_face_colors else color))
    faces.append((list(range(n)), get_random_color() if random_face_colors else color))
    return ModelData(vertices, faces)


def generate_cube(size: float, color: Tuple, random_face_colors: bool) -> ModelData:
    """生成立方体。"""
    s = size / 2.0
    vertices: List[Vertex] = [
        (-s, -s, -s), (s, -s, -s), (s, s, -s), (-s, s, -s),
        (-s, -s, s), (s, -s, s), (s, s, s), (-s, s, s)
    ]
    face_indices = [
        [0, 3, 2, 1], [4, 5, 6, 7], [0, 1, 5, 4],
        [2, 3, 7, 6], [1, 2, 6, 5], [0, 4, 7, 3]
    ]
    faces: List[Face] = [
        (indices, get_random_color() if random_face_colors else color) for indices in face_indices
    ]
    return ModelData(vertices, faces)


def generate_interlocking_cubes(size: float, color: Tuple, random_face_colors: bool) -> ModelData:
    """
    生成一个由三个互相垂直的长方体组成的交叉模型。
    """
    all_vertices = []
    all_faces = []

    # 定义长方体的尺寸
    # 长边是短边的3倍，短边由 'size' 参数控制
    long_side = size * 1.5
    short_side = size * 0.5

    cuboid_dims = [
        (long_side, short_side, short_side),  # X-轴方向
        (short_side, long_side, short_side),  # Y-轴方向
        (short_side, short_side, long_side)  # Z-轴方向
    ]

    vertex_offset = 0
    for dims in cuboid_dims:
        hx, hy, hz = dims[0], dims[1], dims[2]

        # 定义当前长方体的8个顶点
        local_vertices = [
            (-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
            (-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz)
        ]
        all_vertices.extend(local_vertices)

        # 定义当前长方体的6个面，注意顶点索引需要加上偏移量
        face_indices = [
            [0, 3, 2, 1], [4, 5, 6, 7], [0, 1, 5, 4],
            [2, 3, 7, 6], [1, 2, 6, 5], [0, 4, 7, 3]
        ]

        for indices in face_indices:
            # 将局部索引转换为全局索引
            global_indices = [i + vertex_offset for i in indices]
            face_color = get_random_color() if random_face_colors else color
            all_faces.append((global_indices, face_color))

        # 为下一个长方体更新顶点索引偏移量
        vertex_offset += 8

    return ModelData(all_vertices, all_faces)