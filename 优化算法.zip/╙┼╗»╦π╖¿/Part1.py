import numpy as np
import matplotlib.pyplot as plt

# 字体设置 (防止中文乱码)
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows
plt.rcParams['axes.unicode_minus'] = False

# 第一部分：一维函数 f(x) 的梯度下降
# 函数：f(x) = 2x^3 + 6x^2 + 7
def f_1d(x):
    """ 定义函数 f(x) = 2x^3 + 6x^2 + 7 """
    return 2 * x ** 3 + 6 * x ** 2 + 7

def df_1d(x):
    """ 导数 f'(x) = 6x^2 + 12x """
    return 6 * x ** 2 + 12 * x

def visualize_part1():
    print(">>> 正在执行第一部分：f(x) = 2x^3 + 6x^2 + 7 梯度下降 ...")

    # 参数设置
    lr = 0.1  # 学习率
    epochs = 15  # 迭代轮次
    x_start = 1.0  # 初始点

    # 梯度下降过程
    x = x_start
    history_x = [x]
    history_y = [f_1d(x)]

    for _ in range(epochs):
        grad = df_1d(x)
        x = x - lr * grad
        history_x.append(x)
        history_y.append(f_1d(x))

    # 输出最后收敛的点坐标
    final_x = history_x[-1]
    final_y = history_y[-1]
    print(f"第一阶段迭代完成 (Epochs={epochs})")
    print(f"最终收敛坐标: x = {final_x:.6f}, f(x) = {final_y:.6f}")
    print("-" * 30)

    # --- 计算局部放大的视图范围 ---
    h_min, h_max = min(history_x), max(history_x)
    x_margin = (h_max - h_min) * 0.2  # X轴留白 20%

    # 确定视图边界
    view_xmin = h_min - x_margin
    view_xmax = h_max + x_margin

    # 根据视图X范围确定Y范围
    view_x_range = np.linspace(view_xmin, view_xmax, 100)
    view_y_values = f_1d(view_x_range)
    view_ymin = min(view_y_values) - 1
    view_ymax = max(view_y_values) + 1

    # 绘图
    plt.figure(figsize=(10, 6))

    # 重新生成仅覆盖可视区域的平滑曲线数据
    x_range = np.linspace(view_xmin - 0.2, view_xmax + 0.2, 200)
    y_range = f_1d(x_range)

    plt.plot(x_range, y_range, label='f(x) = 2x^3 + 6x^2 + 7', color='blue', alpha=0.6)
    plt.scatter(history_x, history_y, color='red', s=60, label='迭代点', zorder=5)  # 稍微加大点的大小
    plt.plot(history_x, history_y, color='red', linestyle='--', alpha=0.5, label='优化路径')

    # 标注起点和终点
    plt.text(history_x[0], history_y[0] + 0.5, ' Start', fontsize=12, verticalalignment='bottom')
    plt.text(history_x[-1], history_y[-1] - 0.5, ' End', fontsize=12, verticalalignment='top')

    plt.title(f"第一部分：f(x) 梯度下降 (局部放大视图, lr={lr}, epoch={epochs})")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.grid(True, linestyle='--', alpha=0.7)

    # --- 设置显示的坐标轴范围 ---
    plt.xlim(view_xmin, view_xmax)
    plt.ylim(view_ymin, view_ymax)

    plt.legend()
    plt.show()

if __name__ == "__main__":
    visualize_part1()