import numpy as np
import matplotlib.pyplot as plt

# 字体设置 (防止中文乱码)
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows
plt.rcParams['axes.unicode_minus'] = False

# 第一部分：一维函数 f(x) 的梯度下降
# 函数：f(x) = 2x^3 + 6x^2 + 7
def f_1d(x):
    """ 定义函数 f(x) = 2x^3 + 6x^2 + 7 """
    return 2 * x ** 3 + 6 * x ** 2 + 7

def df_1d(x):
    """ 导数 f'(x) = 6x^2 + 12x """
    return 6 * x ** 2 + 12 * x

def visualize_part1():
    print(">>> 正在执行第一部分：f(x) = 2x^3 + 6x^2 + 7 梯度下降 ...")

    # 参数设置
    lr = 0.1  # 学习率
    epochs = 15  # 迭代轮次
    x_start = 1.0  # 初始点

    # 梯度下降过程
    x = x_start
    history_x = [x]
    history_y = [f_1d(x)]

    for _ in range(epochs):
        grad = df_1d(x)
        x = x - lr * grad
        history_x.append(x)
        history_y.append(f_1d(x))

    # 输出最后收敛的点坐标
    final_x = history_x[-1]
    final_y = history_y[-1]
    print(f"第一阶段迭代完成 (Epochs={epochs})")
    print(f"最终收敛坐标: x = {final_x:.6f}, f(x) = {final_y:.6f}")
    print("-" * 30)

    # --- 计算局部放大的视图范围 ---
    h_min, h_max = min(history_x), max(history_x)
    x_margin = (h_max - h_min) * 0.2  # X轴留白 20%

    # 确定视图边界
    view_xmin = h_min - x_margin
    view_xmax = h_max + x_margin

    # 根据视图X范围确定Y范围
    view_x_range = np.linspace(view_xmin, view_xmax, 100)
    view_y_values = f_1d(view_x_range)
    view_ymin = min(view_y_values) - 1
    view_ymax = max(view_y_values) + 1

    # 绘图
    plt.figure(figsize=(10, 6))

    # 重新生成仅覆盖可视区域的平滑曲线数据
    x_range = np.linspace(view_xmin - 0.2, view_xmax + 0.2, 200)
    y_range = f_1d(x_range)

    plt.plot(x_range, y_range, label='f(x) = 2x^3 + 6x^2 + 7', color='blue', alpha=0.6)
    plt.scatter(history_x, history_y, color='red', s=60, label='迭代点', zorder=5)  # 稍微加大点的大小
    plt.plot(history_x, history_y, color='red', linestyle='--', alpha=0.5, label='优化路径')

    # 标注起点和终点
    plt.text(history_x[0], history_y[0] + 0.5, ' Start', fontsize=12, verticalalignment='bottom')
    plt.text(history_x[-1], history_y[-1] - 0.5, ' End', fontsize=12, verticalalignment='top')

    plt.title(f"第一部分：f(x) 梯度下降 (局部放大视图, lr={lr}, epoch={epochs})")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.grid(True, linestyle='--', alpha=0.7)

    # --- 设置显示的坐标轴范围 ---
    plt.xlim(view_xmin, view_xmax)
    plt.ylim(view_ymin, view_ymax)

    plt.legend()
    plt.show()

# 第二部分：二维函数 g(x) 的 Adam 优化
# 函数：g(x) = 2x1^3 + 6x2^2
def g_2d(x1, x2):
    """ 定义函数 g(x) = 2x1^3 + 6x2^2 """
    return 2 * x1 ** 3 + 6 * x2 ** 2

def dg_2d(x1, x2):
    """
    计算梯度
    dg/dx1 = 6 * x1^2
    dg/dx2 = 12 * x2
    """
    grad_x1 = 6 * x1 ** 2
    grad_x2 = 12 * x2
    return np.array([grad_x1, grad_x2])

# Adam 优化器类
class Adam:
    def __init__(self, lr=0.1, start_pos=None, iterations=50):
        self.lr = lr
        self.iterations = iterations
        # 初始点设置为 (2, 2)，以便观察从正区间向0滑落的过程
        self.start_pos = start_pos if start_pos is not None else np.array([2.0, 2.0])
        self.path = []

    def optimize(self, beta1=0.9, beta2=0.999):
        x = self.start_pos.copy()
        self.path = [x.copy()]

        m = np.zeros_like(x)  # 一阶矩
        v = np.zeros_like(x)  # 二阶矩
        epsilon = 1e-8

        for t in range(1, self.iterations + 1):
            grad = dg_2d(x[0], x[1])

            # Adam 核心公式
            m = beta1 * m + (1 - beta1) * grad
            v = beta2 * v + (1 - beta2) * (grad ** 2)

            m_hat = m / (1 - beta1 ** t)
            v_hat = v / (1 - beta2 ** t)

            # 参数更新
            x -= self.lr * m_hat / (np.sqrt(v_hat) + epsilon)
            self.path.append(x.copy())

def visualize_part2():
    print(">>> 正在执行第二部分：g(x) = 2x1^3 + 6x2^2 (Adam Only)...")

    # 设置参数
    start_point = np.array([2.0, 2.0])  # 从正值开始
    iters = 60
    lr = 0.1

    # 实例化 Adam
    adam = Adam(lr=lr, start_pos=start_point, iterations=iters)
    adam.optimize()

    # 转换为数组方便处理
    path = np.array(adam.path)

    # 输出最后收敛的点坐标
    final_pos = path[-1]
    final_val = g_2d(final_pos[0], final_pos[1])
    print(f"第二阶段迭代完成 (Epochs={iters})")
    print(f"最终坐标: (x1, x2) = ({final_pos[0]:.6f}, {final_pos[1]:.6f})")
    print(f"最终函数值: g(x) = {final_val:.6f}")
    print("-" * 30)

    # 因为 x1 可能会变成负数并趋向负无穷，必须动态调整视图
    min_x, max_x = np.min(path[:, 0]), np.max(path[:, 0])
    min_y, max_y = np.min(path[:, 1]), np.max(path[:, 1])

    # 留出边距
    pad_x = (max_x - min_x) * 0.2 if max_x != min_x else 1.0
    pad_y = (max_y - min_y) * 0.2 if max_y != min_y else 1.0

    xlims = (min_x - pad_x, max_x + pad_x)
    ylims = (min_y - pad_y, max_y + pad_y)

    print(f"路径范围检测: x1[{min_x:.2f}, {max_x:.2f}], x2[{min_y:.2f}, {max_y:.2f}]")

    # 绘图
    fig, ax = plt.subplots(figsize=(10, 8))

    # 生成背景等高线
    x1_range = np.linspace(xlims[0], xlims[1], 150)
    x2_range = np.linspace(ylims[0], ylims[1], 150)
    X1, X2 = np.meshgrid(x1_range, x2_range)
    Z = g_2d(X1, X2)

    # 绘制等高线 (增加levels数量以看清陡峭变化)
    cp = ax.contour(X1, X2, Z, 40, cmap='viridis', alpha=0.5)
    plt.colorbar(cp, label='g(x) Value')

    # 绘制路径
    ax.plot(path[:, 0], path[:, 1], 'o-', markersize=4, label='Adam 优化路径',
            color='#FF4500', linewidth=2, zorder=10)

    # 标记起点和终点
    ax.plot(path[0, 0], path[0, 1], 'bx', markersize=10, markeredgewidth=3, zorder=11, label='起点')
    ax.plot(path[-1, 0], path[-1, 1], 'rx', markersize=10, markeredgewidth=3, zorder=11, label='终点')

    # 装饰
    ax.set_title(f"Adam 算法在 g(x) = 2x_1^3 + 6x_2^2 上的收敛过程", fontsize=15)
    ax.set_xlabel("x1 (无全局最小值方向)", fontsize=12)
    ax.set_ylabel("x2 (抛物线方向)", fontsize=12)
    ax.legend(loc='upper right')
    ax.grid(True, linestyle=':', alpha=0.6)

    # 设置动态范围
    ax.set_xlim(xlims)
    ax.set_ylim(ylims)

    plt.subplots_adjust(bottom=0.2)  # 留出底部空间
    plt.show()

if __name__ == "__main__":
    visualize_part1()
    visualize_part2()