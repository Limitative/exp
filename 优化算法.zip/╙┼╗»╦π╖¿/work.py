import numpy as np
import matplotlib.pyplot as plt

# ==========================================
# 0. 全局设置 (字体与随机种子)
# ==========================================
try:
    plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows
    plt.rcParams['axes.unicode_minus'] = False
except:
    try:
        plt.rcParams['font.sans-serif'] = ['Arial Unicode MS']  # Mac
        plt.rcParams['axes.unicode_minus'] = False
    except:
        print("未找到中文字体，使用默认字体")


# ==========================================
# 1. 第一部分：一维函数 f(x) 的梯度下降
# 函数：f(x) = 2x^3 + 6x^2 + 7
# ==========================================

def f_1d(x):
    return 2 * x ** 3 + 6 * x ** 2 + 7


def df_1d(x):
    return 6 * x ** 2 + 12 * x


def visualize_part1():
    print("=" * 40)
    print(">>> 第一部分：f(x) = 2x^3 + 6x^2 + 7 梯度下降")
    print("=" * 40)

    lr = 0.1
    epochs = 15
    x_start = 1.0

    x = x_start
    history_x = [x]
    history_y = [f_1d(x)]

    for _ in range(epochs):
        grad = df_1d(x)
        x = x - lr * grad
        history_x.append(x)
        history_y.append(f_1d(x))

    # 输出结果
    final_x = history_x[-1]
    final_y = history_y[-1]
    print(f"迭代轮次: {epochs}")
    print(f"最终收敛坐标: x = {final_x:.6f}, f(x) = {final_y:.6f}")
    print("-" * 40)

    # 计算局部视图范围
    h_min, h_max = min(history_x), max(history_x)
    x_margin = (h_max - h_min) * 0.2
    view_xmin, view_xmax = h_min - x_margin, h_max + x_margin

    view_x_range = np.linspace(view_xmin, view_xmax, 100)
    view_y_values = f_1d(view_x_range)
    view_ymin, view_ymax = min(view_y_values) - 1, max(view_y_values) + 1

    # 绘图
    plt.figure(figsize=(10, 6))
    x_range = np.linspace(view_xmin - 0.2, view_xmax + 0.2, 200)
    y_range = f_1d(x_range)

    plt.plot(x_range, y_range, label='f(x)', color='blue', alpha=0.6)
    plt.scatter(history_x, history_y, color='red', s=60, label='迭代点', zorder=5)
    plt.plot(history_x, history_y, color='red', linestyle='--', alpha=0.5, label='路径')

    plt.text(history_x[0], history_y[0] + 0.5, ' Start', fontsize=12)
    plt.text(history_x[-1], history_y[-1] - 0.5, f' End\n({final_x:.4f}, {final_y:.4f})', fontsize=12,
             verticalalignment='top')

    plt.title(f"Part 1: f(x) 梯度下降 (局部视图)")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.xlim(view_xmin, view_xmax)
    plt.ylim(view_ymin, view_ymax)
    plt.legend()
    plt.show()


# ==========================================
# 2. 第二部分：二维函数 g(x) 的五种优化算法
# 函数：g(x) = 2x1^3 + 6x2^2
# ==========================================

def g_2d(x1, x2):
    return 2 * x1 ** 3 + 6 * x2 ** 2


def dg_2d(x1, x2):
    grad_x1 = 6 * x1 ** 2
    grad_x2 = 12 * x2
    return np.array([grad_x1, grad_x2])


# --- 优化器类定义 ---

class Optimizer:
    def __init__(self, name, lr=0.01, start_pos=None, iterations=50):
        self.name = name
        self.lr = lr
        self.iterations = iterations
        self.start_pos = start_pos if start_pos is not None else np.array([2.0, 2.0])
        self.path = []

    def optimize(self):
        pass


class SGD(Optimizer):
    def optimize(self):
        x = self.start_pos.copy()
        self.path = [x.copy()]
        for _ in range(self.iterations):
            grad = dg_2d(x[0], x[1])
            x -= self.lr * grad
            self.path.append(x.copy())


class AdaGrad(Optimizer):
    def optimize(self):
        x = self.start_pos.copy()
        self.path = [x.copy()]
        G = np.zeros_like(x)
        epsilon = 1e-8
        for _ in range(self.iterations):
            grad = dg_2d(x[0], x[1])
            G += grad ** 2
            x -= self.lr / (np.sqrt(G) + epsilon) * grad
            self.path.append(x.copy())


class RMSProp(Optimizer):
    def optimize(self, beta=0.9):
        x = self.start_pos.copy()
        self.path = [x.copy()]
        E_g2 = np.zeros_like(x)
        epsilon = 1e-8
        for _ in range(self.iterations):
            grad = dg_2d(x[0], x[1])
            E_g2 = beta * E_g2 + (1 - beta) * (grad ** 2)
            x -= self.lr / (np.sqrt(E_g2) + epsilon) * grad
            self.path.append(x.copy())


class Adadelta(Optimizer):
    def optimize(self, rho=0.9):
        x = self.start_pos.copy()
        self.path = [x.copy()]
        E_g2 = np.zeros_like(x)
        E_dx2 = np.zeros_like(x)
        epsilon = 1e-6
        for _ in range(self.iterations):
            grad = dg_2d(x[0], x[1])
            E_g2 = rho * E_g2 + (1 - rho) * (grad ** 2)
            rms_dx = np.sqrt(E_dx2 + epsilon)
            rms_g = np.sqrt(E_g2 + epsilon)
            delta_x = - (rms_dx / rms_g) * grad
            E_dx2 = rho * E_dx2 + (1 - rho) * (delta_x ** 2)
            x += delta_x
            self.path.append(x.copy())


class Adam(Optimizer):
    def optimize(self, beta1=0.9, beta2=0.999):
        x = self.start_pos.copy()
        self.path = [x.copy()]
        m = np.zeros_like(x)
        v = np.zeros_like(x)
        epsilon = 1e-8
        for t in range(1, self.iterations + 1):
            grad = dg_2d(x[0], x[1])
            m = beta1 * m + (1 - beta1) * grad
            v = beta2 * v + (1 - beta2) * (grad ** 2)
            m_hat = m / (1 - beta1 ** t)
            v_hat = v / (1 - beta2 ** t)
            x -= self.lr * m_hat / (np.sqrt(v_hat) + epsilon)
            self.path.append(x.copy())


def visualize_part2():
    print("=" * 40)
    print(">>> 第二部分：g(x) = 2x1^3 + 6x2^2 五种算法对比")
    print("=" * 40)

    start_point = np.array([2.0, 2.0])
    iters = 50
    base_lr = 0.1  # 基础学习率

    # 初始化五种算法
    # 注意：AdaGrad 通常需要更大的学习率才能在初期移动明显
    optimizers = [
        SGD("SGD", lr=base_lr * 0.5, start_pos=start_point, iterations=iters),
        AdaGrad("AdaGrad", lr=base_lr * 5, start_pos=start_point, iterations=iters),
        RMSProp("RMSProp", lr=base_lr, start_pos=start_point, iterations=iters),
        Adadelta("Adadelta", lr=1.0, start_pos=start_point, iterations=iters),
        Adam("Adam", lr=base_lr, start_pos=start_point, iterations=iters)
    ]

    # 绘图准备
    fig = plt.figure(figsize=(18, 10))
    # 布局：2行3列 (最后一个位置留空或放文本)
    plot_pos = [1, 2, 3, 4, 5]

    for i, opt in enumerate(optimizers):
        # 1. 运行优化
        opt.optimize()
        path = np.array(opt.path)
        final_pos = path[-1]
        final_val = g_2d(final_pos[0], final_pos[1])

        # 2. 输出结果到控制台
        print(f"[{opt.name}] 迭代完成")
        print(f"  最终坐标: ({final_pos[0]:.6f}, {final_pos[1]:.6f})")
        print(f"  最终函数值: {final_val:.6f}")
        print("-" * 20)

        # 3. 计算每个子图独立的动态范围
        # 这样可以保证 AdaGrad（移动距离短）和 SGD/Adam（可能跑飞）都能看清
        min_x, max_x = np.min(path[:, 0]), np.max(path[:, 0])
        min_y, max_y = np.min(path[:, 1]), np.max(path[:, 1])
        pad_x = (max_x - min_x) * 0.2 if max_x != min_x else 1.0
        pad_y = (max_y - min_y) * 0.2 if max_y != min_y else 1.0
        xlims = (min_x - pad_x, max_x + pad_x)
        ylims = (min_y - pad_y, max_y + pad_y)

        # 4. 绘图
        ax = fig.add_subplot(2, 3, plot_pos[i])

        # 生成背景等高线
        x1_range = np.linspace(xlims[0], xlims[1], 100)
        x2_range = np.linspace(ylims[0], ylims[1], 100)
        X1, X2 = np.meshgrid(x1_range, x2_range)
        Z = g_2d(X1, X2)

        ax.contour(X1, X2, Z, 20, cmap='viridis', alpha=0.4)

        # 绘制路径
        ax.plot(path[:, 0], path[:, 1], 'o-', markersize=3, label=opt.name, color='#FF4500')
        ax.plot(path[0, 0], path[0, 1], 'bx', markersize=8, markeredgewidth=2, label='Start')
        ax.plot(path[-1, 0], path[-1, 1], 'rx', markersize=8, markeredgewidth=2, label='End')

        # 标题包含最终坐标
        ax.set_title(f"{opt.name}\nEnd: ({final_pos[0]:.2f}, {final_pos[1]:.2f})")
        ax.set_xlim(xlims)
        ax.set_ylim(ylims)
        ax.grid(True, linestyle=':', alpha=0.6)

    # 最后一个子图用于显示说明
    ax_text = fig.add_subplot(2, 3, 6)
    ax_text.axis('off')
    info = (
        "算法行为分析：\n\n"
        "1. SGD: 容易震荡，需要仔细调参。\n"
        "2. AdaGrad: 学习率衰减快，\n   初期移动后容易过早停止。\n"
        "3. RMSProp/Adadelta: \n   比AdaGrad更持久，\n   能持续向谷底移动。\n"
        "4. Adam: 结合动量。\n   收敛快，但因惯性大，\n   容易在x1方向冲入负值区导致发散。"
    )
    ax_text.text(0.1, 0.5, info, fontsize=12, verticalalignment='center')

    plt.suptitle("五种优化算法在 g(x)=2x_1^3 + 6x_2^2 上的收敛对比 (独立视角)", fontsize=16)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    visualize_part1()
    visualize_part2()