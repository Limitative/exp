import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 1. 定义三个函数
# f(x) = 0.5 * x^2 (凸函数)
f = lambda x: 0.5 * x ** 2
# g(x) = cos(π * x) (非凸函数)
g = lambda x: np.cos(np.pi * x)
# h(x) = exp(0.5 * x) (凸函数)
h = lambda x: np.exp(0.5 * x)

# 将函数和它们的标题存放在列表中，方便循环处理
functions = [f, g, h]
titles = [
    'f(x) = 0.5 * x ** 2 (凸函数)',
    'g(x) = cos(πx) (非凸函数)',
    'h(x) = exp(0.5x) (凸函数)'
]

# 2. 定义数据范围
# 用于绘制平滑曲线的 x 坐标点，从 -2 到 2，步长为 0.01
x_curve = np.arange(-2, 2, 0.01)
# 用于绘制虚线线段的两个端点的 x 坐标
x_segment = np.array([-1.5, 1])

# 3. 创建图表和子图
# 创建一个 1 行 3 列的图表布局，图像大小为 9x3 英寸
fig, axes = plt.subplots(1, 3, figsize=(12, 4))

# 4. 循环绘制三个子图
for ax, func, title in zip(axes, functions, titles):
    # a. 绘制蓝色实线函数曲线
    ax.plot(x_curve, func(x_curve), '-')

    # b. 绘制连接两个点的紫色虚线线段
    #    首先计算线段端点的 y 值
    y_segment = func(x_segment)
    #    然后绘制线段
    ax.plot(x_segment, y_segment, 'm--')  # 'm--' 代表 magenta (品红色) 的虚线

    # c. 添加网格和标题
    ax.grid(True)
    ax.set_title(title)
    ax.set_xlabel('x')
    ax.set_ylabel('f(x)')

# 调整子图之间的间距，防止标题重叠
plt.tight_layout()

# 5. 显示最终的图表
plt.show()