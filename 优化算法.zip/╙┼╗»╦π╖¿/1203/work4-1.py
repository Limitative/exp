import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 1. 定义目标函数
def f(x):
    return 2 * x ** 3 + 6 * x ** 2 + 7

# 2. 定义目标函数的梯度（导数）
def f_grad(x):
    return 6 * x ** 2 + 12 * x

# 3. 执行梯度下降
def gradient_descent(start_x, gamma, n_iters):
    x = start_x
    history = [x]  # 使用列表记录 x 的每一次更新值

    print("--- 梯度下降过程 ---")
    print(f"第 0 轮: x = {x:.6f}")

    for i in range(n_iters):
        # 计算梯度
        grad = f_grad(x)
        # 更新 x: x_{t+1} = x_t - γ * f'(x_t)
        x = x - gamma * grad
        history.append(x)
        print(f"第 {i + 1} 轮: x = {x:.6f}")

    return history


# 4. 可视化函数
def plot_trace(history, func):
    plt.figure(figsize=(12, 8))

    x_curve = np.linspace(-3, 2, 400)
    y_curve = func(x_curve)
    plt.plot(x_curve, y_curve, label='函数 $f(x) = 2x^3 + 6x^2 + 7$')

    x_trace = np.array(history)
    y_trace = func(x_trace)
    plt.plot(x_trace, y_trace, 'o-', color='darkorange', markersize=8,
             label=f'梯度下降轨迹 (γ={gamma}, 初始点={start_x})')

    # 标记起点和终点
    plt.scatter(x_trace[0], y_trace[0], color='red', s=150, zorder=5, label='起点')
    plt.scatter(x_trace[-1], y_trace[-1], color='green', s=150, zorder=5, label='终点')

    # 设置图表样式
    plt.title("梯度下降寻找函数极值过程", fontsize=16)
    plt.xlabel("x", fontsize=12)
    plt.ylabel("f(x)", fontsize=12)
    plt.grid(True)
    plt.legend(fontsize=12)
    plt.show()

if __name__ == "__main__":
    gamma = 0.1  # 学习率
    n_iterations = 15  # 迭代轮次
    start_x = 1.0  # 初始点

    optimization_history = gradient_descent(start_x, gamma, n_iterations)
    plot_trace(optimization_history, f)