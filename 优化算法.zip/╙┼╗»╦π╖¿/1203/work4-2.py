import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 1. 定义目标函数
def g(x):
    x1, x2 = x[0], x[1]
    return 2 * x1 ** 3 + 6 * x2 ** 2

# 2. 定义目标函数的真实梯度
def g_grad(x):
    x1, x2 = x[0], x[1]
    return np.array([6 * x1 ** 2, 12 * x2])

# 3. 实现 SGD 算法
def sgd(start_x, gamma, n_iters, noise_level=2.0):
    x = np.array(start_x, dtype=float)
    history = [x.copy()]

    print("--- SGD 优化过程 ---")
    print(f"第 0 轮: x = [{x[0]:.4f}, {x[1]:.4f}]")

    for i in range(n_iters):
        # 计算真实梯度
        true_grad = g_grad(x)
        # 添加高斯噪声来模拟随机梯度
        noise = np.random.randn(2) * noise_level
        stochastic_grad = true_grad + noise

        # 更新 x
        x -= gamma * stochastic_grad
        history.append(x.copy())
        print(f"第 {i + 1} 轮: x = [{x[0]:.4f}, {x[1]:.4f}]")

    return history

# 4. 可视化函数 (3D曲面图 和 2D等高线图)
def visualize_optimization(history, func):
    history_np = np.array(history)

    # 创建网格数据用于绘图
    x1_range = np.linspace(min(history_np[:, 0]) - 1, max(history_np[:, 0]) + 1, 100)
    x2_range = np.linspace(min(history_np[:, 1]) - 1, max(history_np[:, 1]) + 1, 100)
    X1, X2 = np.meshgrid(x1_range, x2_range)
    Z = func([X1, X2])

    # 创建包含两个子图的画布
    fig = plt.figure(figsize=(20, 9))

    # --- 第一个子图: 3D 曲面图 ---
    ax1 = fig.add_subplot(1, 2, 1, projection='3d')
    ax1.plot_surface(X1, X2, Z, cmap='viridis', alpha=0.7, edgecolor='k', linewidth=0.1)

    # 绘制轨迹
    x1_hist, x2_hist = history_np[:, 0], history_np[:, 1]
    z_hist = func([x1_hist, x2_hist])
    ax1.plot(x1_hist, x2_hist, z_hist, 'o-', color='red', markersize=5, linewidth=2, label='SGD 轨迹')

    ax1.set_title('3D曲面上的SGD优化路径', fontsize=16)
    ax1.set_xlabel('$x_1$', fontsize=12)
    ax1.set_ylabel('$x_2$', fontsize=12)
    ax1.set_zlabel('$g(x)$', fontsize=12)
    ax1.legend()

    # --- 第二个子图: 2D 等高线图 ---
    ax2 = fig.add_subplot(1, 2, 2)
    # 绘制填充的等高线
    contour = ax2.contourf(X1, X2, Z, levels=20, cmap='viridis', alpha=0.8)
    # 添加等高线线条
    ax2.contour(X1, X2, Z, levels=20, colors='black', linewidths=0.5)
    fig.colorbar(contour, ax=ax2, label='$g(x)$ 值')

    # 绘制轨迹
    ax2.plot(x1_hist, x2_hist, 'o-', color='red', markersize=5, label='SGD 轨迹')
    ax2.scatter(history_np[0, 0], history_np[0, 1], color='blue', s=150, zorder=5, label='起点')
    ax2.scatter(history_np[-1, 0], history_np[-1, 1], color='lime', s=150, zorder=5, label='终点')

    ax2.set_title('2D等高线图上的SGD优化路径', fontsize=16)
    ax2.set_xlabel('$x_1$', fontsize=12)
    ax2.set_ylabel('$x_2$', fontsize=12)
    ax2.grid(True)
    ax2.legend()
    ax2.axis('equal')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    gamma = 0.02  # 学习率
    n_iterations = 30  # 迭代次数
    initial_point = [1.0, 1.0]  # 初始点

    sgd_history = sgd(initial_point, gamma, n_iterations)
    visualize_optimization(sgd_history, g)