import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 1. 定义目标函数
def f(x):
    return x ** 2

# 2. 定义目标函数的梯度（导数）
def f_grad(x):
    return 2 * x

# 3. 实现梯度下降函数
def gradient_descent(eta, grad_func):
    x = 5.0  # 初始值
    results = [x]  # 存储每一次迭代的 x 值

    # 迭代10次
    for i in range(10):
        x -= eta * grad_func(x)
        results.append(x)

    # 打印最终结果
    print(f"Epoch 10, x 的最终值为: {x:.6f}")
    return results

# 4. 实现可视化函数
def show_trace(results, func):
    plt.figure(figsize=(8, 6))

    n = max(np.abs(min(results)), np.abs(max(results)))
    x_curve = np.arange(-n, n, 0.01)
    y_curve = func(x_curve)
    plt.plot(x_curve, y_curve, label='函数 f(x) = x^2')

    # 绘制梯度下降的轨迹点
    x_trace = np.array(results)
    y_trace = func(x_trace)
    # 'o-' 表示用圆点标记数据点，并用线连接起来
    plt.plot(x_trace, y_trace, 'o-', color='darkorange', label='梯度下降轨迹 (lr=0.1)')

    # d. 设置图表样式
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.title("梯度下降优化过程可视化")
    plt.grid(True)
    plt.legend()
    plt.show()

# 设置学习率
learning_rate = 0.1
# 运行梯度下降算法，获取 x 的变化轨迹
optimization_trace = gradient_descent(learning_rate, f_grad)
# 将轨迹可视化
show_trace(optimization_trace, f)