import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from mpl_toolkits.mplot3d import Axes3D

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# --- 问题一：求解函数 f(x) = x * cos(πx) 的局部与全局最小值并可视化 ---

# 1.1 定义函数
def f1(x):
    return x * np.cos(np.pi * x)

# 1.2 生成数据点
x_vals = np.linspace(-1.0, 2.0, 301)
y_vals = f1(x_vals)

# 1.3 寻找最小值
# 全局最小值
global_min_index = np.argmin(y_vals)
x_global_min = x_vals[global_min_index]
y_global_min = y_vals[global_min_index]

# 寻找所有局部最小值 (通过对 -y 寻找波峰)
minima_indices, _ = find_peaks(-y_vals)
# 筛选出非全局最小值的局部最小值
local_min_index_list = [idx for idx in minima_indices if not np.isclose(x_vals[idx], x_global_min)]
if local_min_index_list:
    local_min_index = local_min_index_list[0]
    x_local_min = x_vals[local_min_index]
    y_local_min = y_vals[local_min_index]
else:
    # 如果没有找到其他局部最小值，则标记为不存在
    x_local_min, y_local_min = None, None


# 1.4 可视化第一个图表
print("--- 正在生成第一个图表：f(x) = x * cos(πx) 的最小值分析 ---")
plt.figure(figsize=(10, 7)) # 创建第一个图形窗口
plt.plot(x_vals, y_vals, label='f(x) = x * cos(πx)')
plt.grid(True)
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('f(x) 的全局最小值和局部最小值')

# 标记并注释全局最小值
plt.plot(x_global_min, y_global_min, 'ro') # 红点
plt.annotate(f'Global Minimum\n({x_global_min:.2f}, {y_global_min:.2f})',
             xy=(x_global_min, y_global_min),
             xytext=(x_global_min - 0.7, y_global_min + 0.5),
             arrowprops=dict(facecolor='black', shrink=0.05, width=1, headwidth=8))

# 标记并注释局部最小值
if x_local_min is not None:
    plt.plot(x_local_min, y_local_min, 'bo') # 蓝点
    plt.annotate(f'Local Minimum\n({x_local_min:.2f}, {y_local_min:.2f})',
                 xy=(x_local_min, y_local_min),
                 xytext=(x_local_min + 0.4, y_local_min - 0.5),
                 arrowprops=dict(facecolor='black', shrink=0.05, width=1, headwidth=8))

plt.legend()
# 先不显示，等待第二个图表代码执行完毕

# --- 问题二：求解函数 f(x, y) = x² - y² 的鞍点并可视化 ---

# 2.1 定义函数
def f2(x, y):
    """计算 f(x, y) = x² - y²"""
    return x**2 - y**2

# 2.2 生成网格数据
x_3d = np.linspace(-1.5, 1.5, 100)
y_3d = np.linspace(-1.5, 1.5, 100)
X, Y = np.meshgrid(x_3d, y_3d)
Z = f2(X, Y)

# 2.3 鞍点坐标
saddle_point_x = 0
saddle_point_y = 0
saddle_point_z = f2(saddle_point_x, saddle_point_y)

# 2.4 可视化第二个图表
print("--- 正在生成第二个图表：f(x, y) = x² - y² 的鞍点分析 ---")
fig_3d = plt.figure(figsize=(10, 8)) # 创建第二个图形窗口
ax = fig_3d.add_subplot(111, projection='3d')

# 绘制三维线框图
ax.plot_wireframe(X, Y, Z, rstride=8, cstride=8, linewidth=0.8, color='dodgerblue', alpha=0.8)

# 标记鞍点
ax.scatter([saddle_point_x], [saddle_point_y], [saddle_point_z], color='red', s=150, label=f'Saddle Point ({saddle_point_x}, {saddle_point_y}, {saddle_point_z})', depthshade=True)

# 设置坐标轴标签和标题
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.set_zlabel('f(x, y)')
ax.set_title('Saddle Point of f(x, y) = x² - y²')
ax.legend()

# --- 显示所有图表并打印结果 ---
print("\n--- 数值计算结果汇总 ---")
print(f"函数 f(x) = x * cos(πx):")
if y_local_min is not None:
    print(f"  - 局部最小点近似为: x = {x_local_min:.4f}, f(x) = {y_local_min:.4f}")
print(f"  - 全局最小点近似为: x = {x_global_min:.4f}, f(x) = {y_global_min:.4f}")

print(f"\n函数 f(x, y) = x² - y²:")
print(f"  - 鞍点位于: ({saddle_point_x}, {saddle_point_y}, {saddle_point_z})")

# 显示所有已创建的图形窗口
plt.show()