import numpy as np
import matplotlib.pyplot as plt

# 字体设置 (防止中文乱码)
# Windows 系统常用字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 第一部分：一维函数 f(x) 的梯度下降
def f_1d(x):
    """ 定义函数 f(x) = 3x^3 + 2x^2 + 2 """
    return 3 * x ** 3 + 2 * x ** 2 + 2

def df_1d(x):
    """ f(x) 的导数 f'(x) = 9x^2 + 4x """
    return 9 * x ** 2 + 4 * x

def visualize_part1():
    print(">>> 正在执行第一部分：f(x) 梯度下降可视化...")

    # 参数设置
    lr = 0.1  # 学习率
    epochs = 15  # 迭代轮次
    x_start = 1.0  # 初始点

    # 梯度下降过程
    x = x_start
    history_x = [x]
    history_y = [f_1d(x)]

    for _ in range(epochs):
        grad = df_1d(x)
        x = x - lr * grad
        history_x.append(x)
        history_y.append(f_1d(x))

    # 绘图
    plt.figure(figsize=(10, 6))

    # 生成函数曲线数据
    x_range = np.linspace(-1.5, 1.2, 100)
    y_range = f_1d(x_range)

    plt.plot(x_range, y_range, label='f(x) = 3x^3 + 2x^2 + 2', color='blue', alpha=0.6)
    plt.scatter(history_x, history_y, color='red', s=50, label='迭代点', zorder=5)
    plt.plot(history_x, history_y, color='red', linestyle='--', alpha=0.5, label='优化路径')

    # 标注起点和终点
    plt.text(history_x[0], history_y[0], ' Start', fontsize=12, verticalalignment='bottom')
    plt.text(history_x[-1], history_y[-1], ' End', fontsize=12, verticalalignment='top')

    plt.title(f"第一部分：f(x) 梯度下降 (lr={lr}, iter={epochs})")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend()
    plt.show()


# 第二部分：二维函数 g(x) 的优化 ( Adadelta 和 Adam)
def g_2d(x1, x2):
    """ 定义函数 g(x) = 6x1^3 + 3x2^2 """
    return 6 * x1 ** 3 + 3 * x2 ** 2

def dg_2d(x1, x2):
    """
    计算梯度
    dg/dx1 = 18 * x1^2
    dg/dx2 = 6 * x2
    """
    grad_x1 = 18 * x1 ** 2
    grad_x2 = 6 * x2
    return np.array([grad_x1, grad_x2])

# 优化器基类
class Optimizer:
    def __init__(self, name, lr=0.01, start_pos=None, iterations=50):
        self.name = name
        self.lr = lr
        self.iterations = iterations
        # 默认起始点
        self.start_pos = start_pos if start_pos is not None else np.array([0.5, 0.5])
        self.path = []  # 记录路径

    def optimize(self):
        pass

# 1. Adadelta 算法
class Adadelta(Optimizer):
    def optimize(self, rho=0.9):
        # Adadelta 不需要全局学习率，主要依赖 rho 和 epsilon
        x = self.start_pos.copy()
        self.path = [x.copy()]

        E_g2 = np.zeros_like(x)  # 梯度平方的移动平均
        E_dx2 = np.zeros_like(x)  # 更新量平方的移动平均
        epsilon = 1e-6

        for _ in range(self.iterations):
            grad = dg_2d(x[0], x[1])

            # 1. 累积梯度平方
            E_g2 = rho * E_g2 + (1 - rho) * (grad ** 2)
            # 2. 计算更新量 RMS
            rms_dx = np.sqrt(E_dx2 + epsilon)
            rms_g = np.sqrt(E_g2 + epsilon)
            # 3. 计算 delta_x
            delta_x = - (rms_dx / rms_g) * grad
            # 4. 累积更新量平方
            E_dx2 = rho * E_dx2 + (1 - rho) * (delta_x ** 2)

            # 5. 更新参数
            x += delta_x
            self.path.append(x.copy())

# 2. Adam 算法
class Adam(Optimizer):
    def optimize(self, beta1=0.9, beta2=0.999):
        x = self.start_pos.copy()
        self.path = [x.copy()]

        m = np.zeros_like(x)  # 一阶矩 (均值)
        v = np.zeros_like(x)  # 二阶矩 (方差)
        epsilon = 1e-8

        for t in range(1, self.iterations + 1):
            grad = dg_2d(x[0], x[1])

            # 1. 更新有偏一阶矩估计
            m = beta1 * m + (1 - beta1) * grad
            # 2. 更新有偏二阶矩估计
            v = beta2 * v + (1 - beta2) * (grad ** 2)
            # 3. 偏差修正
            m_hat = m / (1 - beta1 ** t)
            v_hat = v / (1 - beta2 ** t)

            # 4. 更新参数
            x -= self.lr * m_hat / (np.sqrt(v_hat) + epsilon)
            self.path.append(x.copy())


def visualize_part2():
    print(">>> 正在执行第二部分：Adadelta 与 Adam 对比...")

    # 全局设置
    # 选择起始点 (0.5, 1.5)，避开x1负半轴的极速发散区，观察趋近(0,0)的过程
    start_point = np.array([0.5, 1.5])
    iters = 60  # 迭代次数

    # 实例化算法 ( Adadelta 和 Adam)
    optimizers = [
        # Adadelta 只有 rho 参数，lr参数其实不生效（算法内部自适应）
        Adadelta("Adadelta", lr=1.0, start_pos=start_point, iterations=iters),
        # Adam 需要较小的 lr，防止在 x1 方向动量过大瞬间飞出
        Adam("Adam", lr=0.05, start_pos=start_point, iterations=iters)
    ]

    # 1. 运行优化并记录路径
    all_paths = []
    for opt in optimizers:
        opt.optimize()
        all_paths.extend(opt.path)

    all_paths = np.array(all_paths)

    # 2. 动态计算坐标轴范围 (关键：防止Adam冲出画面后消失)
    # 获取所有点的边界
    min_x, max_x = np.min(all_paths[:, 0]), np.max(all_paths[:, 0])
    min_y, max_y = np.min(all_paths[:, 1]), np.max(all_paths[:, 1])

    # 添加 15% 的边距 padding
    pad_x = (max_x - min_x) * 0.15 if max_x != min_x else 0.5
    pad_y = (max_y - min_y) * 0.15 if max_y != min_y else 0.5

    xlims = (min_x - pad_x, max_x + pad_x)
    ylims = (min_y - pad_y, max_y + pad_y)

    print(f"动态坐标范围: X{xlims}, Y{ylims}")

    # 3. 绘图
    fig, axes = plt.subplots(1, 2, figsize=(14, 7))

    # 生成背景等高线数据
    x1_range = np.linspace(xlims[0], xlims[1], 100)
    x2_range = np.linspace(ylims[0], ylims[1], 100)
    X1, X2 = np.meshgrid(x1_range, x2_range)
    Z = g_2d(X1, X2)

    for i, opt in enumerate(optimizers):
        ax = axes[i]

        # 绘制背景等高线
        ax.contour(X1, X2, Z, 30, cmap='viridis', alpha=0.5)

        # 提取路径
        path = np.array(opt.path)

        # 绘制优化路径 (橙色实线)
        ax.plot(path[:, 0], path[:, 1], 'o-', markersize=4, label=f'{opt.name} 路径',
                color='#FF8C00', linewidth=2, zorder=10)

        # 标记起点 (蓝色叉)
        ax.plot(path[0, 0], path[0, 1], 'bx', markersize=10, markeredgewidth=3, zorder=11, label='起点')
        # 标记终点 (红色叉)
        ax.plot(path[-1, 0], path[-1, 1], 'rx', markersize=10, markeredgewidth=3, zorder=11, label='终点')

        # 设置标题和标签
        ax.set_title(f"{opt.name} 收敛轨迹", fontsize=14)
        ax.set_xlabel("x1")
        ax.set_ylabel("x2")
        ax.grid(True, linestyle=':', alpha=0.7)
        ax.legend()

        # 应用动态范围
        ax.set_xlim(xlims)
        ax.set_ylim(ylims)

    # 添加整体说明
    plt.suptitle("Adadelta 与 Adam 在 g(x)=6x_1^3 + 3x_2^2 上的对比", fontsize=16)

    # 在图表下方添加分析文本
    analysis_text = (
        "分析结论：\n"
        "1. Adadelta: 不需要手动设置学习率。在这个非凸函数上，它表现出稳健的下降趋势，\n"
        "   虽然初期可能比Adam慢，但能稳定地逼近驻点(0,0)，不易发生剧烈震荡。\n"
        "2. Adam: 利用动量(Momentum)加速收敛。由于x1方向梯度(18x^2)很大，\n"
        "   Adam在接近0点时积累了较大的动量，容易冲过头进入负数区域。\n"
        "   一旦进入负数区，函数性质导致其加速向负无穷发散（如右图末端所示）。"
    )
    plt.figtext(0.5, 0.01, analysis_text, ha="center", fontsize=12,
                bbox={"facecolor": "orange", "alpha": 0.1, "pad": 10})

    plt.tight_layout(rect=[0, 0.1, 1, 0.95])  # 调整布局给下方文字留空间
    plt.show()

if __name__ == "__main__":
    visualize_part1()
    visualize_part2()