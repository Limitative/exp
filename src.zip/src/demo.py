import os
import argparse
import torch
import cv2
import numpy as np
from test import GOTURN

# ================= 配置区：请确认路径符合你的电脑 =================
MODEL_PATH = r'C:\ros\detection\pytorch_goturn.pth'
DATA_PATH = r'C:\ros\detection\pygoturn\pygoturn-master\data\OTB\Man'
SAVE_PATH = r'C:\ros\detection\pygoturn\pygoturn-master\result'

# ================================================================

def axis_aligned_iou(boxA, boxB):
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    interArea = max(0, xB - xA + 1) * max(0, yB - yA + 1)
    boxAArea = (boxA[2] - boxA[0] + 1) * (boxA[3] - boxA[1] + 1)
    boxBArea = (boxB[2] - boxB[0] + 1) * (boxB[3] - boxB[1] + 1)
    iou = interArea / float(boxAArea + boxBArea - interArea)
    return iou


def save_and_show(im, bb, gt_bb, idx):
    # GOTURN内部使用RGB，OpenCV显示和保存需要BGR
    im_bgr = cv2.cvtColor(im, cv2.COLOR_RGB2BGR)
    bb = [int(val) for val in bb]
    gt_bb = [int(val) for val in gt_bb]

    # 红色框：GOTURN预测
    cv2.rectangle(im_bgr, (bb[0], bb[1]), (bb[2], bb[3]), (0, 0, 255), 2)
    # 白色框：GroundTruth标签
    cv2.rectangle(im_bgr, (gt_bb[0], gt_bb[1]), (gt_bb[2], gt_bb[3]), (255, 255, 255), 2)

    # 在图片上标注帧号
    cv2.putText(im_bgr, f"Frame: {idx}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

    # 实时显示
    cv2.imshow("GOTURN Tracking (Press Q to quit)", im_bgr)

    # 保存图片
    if not os.path.exists(SAVE_PATH):
        os.makedirs(SAVE_PATH)
    cv2.imwrite(os.path.join(SAVE_PATH, f"{idx:04d}.jpg"), im_bgr)

    return cv2.waitKey(1) & 0xFF == ord('q')


def main():
    cuda = torch.cuda.is_available()
    device = torch.device('cuda:0' if cuda else 'cpu')
    print(f"Using device: {device}")

    # 初始化测试器
    tester = GOTURN(DATA_PATH, MODEL_PATH, device)
    tester.model.eval()

    print(f"Start tracking... Results will be saved to: {SAVE_PATH}")

    # 保存第一帧
    save_and_show(tester.img[0][0], tester.prev_rect, tester.prev_rect, 1)

    # 循环处理后续帧
    for i in range(tester.len):
        sample = tester[i]
        bb = tester.get_rect(sample)
        gt_bb = tester.gt[i]
        tester.prev_rect = bb

        im = tester.img[i][1]

        # 打印 IoU 结果
        iou = axis_aligned_iou(gt_bb, bb)
        print(f'Frame: {i + 2}, IoU = {iou:.4f}')

        # 显示与保存
        quit_flag = save_and_show(im, bb, gt_bb, i + 2)
        if quit_flag:
            break

    cv2.destroyAllWindows()
    print("Tracking finished.")


if __name__ == "__main__":
    main()